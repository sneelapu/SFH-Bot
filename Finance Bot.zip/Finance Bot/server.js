const restify = require('restify');
const moment = require('moment')
const logger = require('./app/_log/logger_def.js');
require('dotenv').config();

// Setup Restify Server
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3979, function () {
  logger.info("--------------------------------------------------------");
  logger.info(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Finance Bot is running with the address : " + server.url);
  logger.info("--------------------------------------------------------");
});


require('./app/controllers/financeController')(server, logger);
module.exports = server;
