//Requiring Mongoose
const mongoose = require('mongoose');
const Schema = mongoose.Schema;


//Defining Schema
var botSchema = mongoose.Schema({
    "channelId": {
        type: String,
        required: true
    },
    "user": {
        type: Object,
        required: true
    },
    "bot": {
        type: Object,
        required: true
    },
    "serviceUrl":{
        type: String,
        required: true
    },
    "bot_name":{
        type: String,
        required: true
    },
    "hostname":{
        type: String,
        default: true
    },
    "bot_token": {
      type: String,
      required: true
    },
    "modelUrl":{
        type: String,
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
});

//Exporting the file
module.exports = mongoose.model('sfh_colls', botSchema); //Binding schema to botCollection
// "channelId": message.address.channelId,
// "user": message.address.user,
// "bot":message.address.bot,
// "serviceUrl": message.address.serviceUrl,
// "modelUrl": model,
// "bot_name": 'Finance Bot',
// "hostname": "http://" + ip + ":" + port,
// "bot_token": bot_token