const builder = require('botbuilder');
const LUIS = require('luis-sdk');
const moment = require('moment');
const unirest = require('unirest');
const winston = require('winston');
const bodyParser = require('body-parser');
var jsonfile = require('jsonfile');
var fs = require('fs');
var botsData = 'data.json';

module.exports = function (server, logger) {
  // Create chat connector for communicating with the Bot Framework Service
  var connector = new builder.ChatConnector({
    appId: process.env.appId, //get appId from .env file
    appPassword: process.env.appPassword //get appPassword from .env file
  });

  var inMemoryStorage = new builder.MemoryBotStorage();
  var bot = new builder.UniversalBot(connector).set('storage', inMemoryStorage); 

  var sfhModule = require('../../sfh_logger');
  var sfh = new sfhModule();

  var ip = require('ip').address();
  var port = server.address().port;

  //luis model url
  //var model = 'https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/0c406757-8789-4499-947c-a2b42e5d8d96?subscription-key=dbb1c66f521d4ab18510b3f478108b24&verbose=true&timezoneOffset=0&q='; //get model url from .env file
  var model = process.env.modelUrl;

  var recognizer = new builder.LuisRecognizer(model);
  var dialog = new builder.IntentDialog({
    recognizers: [recognizer]
  });

  server.use(bodyParser.urlencoded({ extended: true }));
  server.use(bodyParser.json());

  //the endpoint of server where connector listens for messages
  server.post('/api/messages', connector.listen());

  //importing start Conversation module
  const startConversation = require('../../startConversation')
  //startConversation.getToken();


  //sending pro-active messages
  function sendProactiveMessage(add, text) {
	  
	//if((source_bot == null) || (source_bot != add.source_bot)){
				  //source_bot = add.source_bot;
	var msg = new builder.Message().address(add);
    msg.text(add.source_bot + ' Bot mentioned that you need some help')
    msg.textLocale('en-US');
	bot.send(msg);
			  //}
	bot.beginDialog(add, "*:"+text);
  }

var text;

  server.post('/receiveSFH', function (req, res) {
    unirest.get(model + req.body.text)
      .headers({
        'Content-Type': 'application/json'
      })
      .end(function (response) {
        if (response.body.topScoringIntent.intent != "None") {
          console.log("--------------------------------------------------------");
          console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Got request from the bot " + req.body.sourceBotName);
          console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | This bot can answer that");
          console.log('------------------------------------------------------------')

		    if (response.body.topScoringIntent.intent) {
            switch (response.body.topScoringIntent.intent) {
         
				case 'Travel':
                    text = "Travel";
                    break;
				case 'Health':
                    text = "Health";
                    break;
				case 'FinanceBot':
                    text = "FinanceBot";
                    break;
				case 'Capabilities':
                    text = "Capabilities";
                    break;
            }
        }
		  
          jsonfile.readFile(botsData, function (err, botObj) {
            botObj.savedAddress.source_bot = req.body.sourceBotName;
            sendProactiveMessage(botObj.savedAddress,text);
          })
		  
          res.send({ 'status': 'success', 'destinationBot': process.env.botName });
        }
        else {
          console.log("--------------------------------------------------------");
          console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Got request from the bot " + req.body.sourceBotName);
          console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | This bot could not answer for that");
          console.log('------------------------------------------------------------')
          res.send({ 'status': 'failed', 'destinationBot': process.env.botName });
        }
      });
  });

  //========================================================================================
  // Cards functionality
  //================================================  
  var createHeroCard = function(session) {
    return new builder.HeroCard(session)
        .title('BotFramework Hero Card')
        .subtitle('Your bots — wherever your users are talking')
        .text('Build and connect intelligent bots to interact with your users naturally wherever they are, from text/sms to Skype, Slack, Office 365 mail and other popular services.')
        .buttons([
            builder.CardAction.imBack(session, 'hi', 'Get Started')
        ]);
}



  //=========================================================
  // Bots Dialogs
  //=========================================================

  bot.dialog('/', dialog);
  
   dialog.matches('Greetings', [
    function (session, args) {
		console.log('hello');
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Greetings Intent Matched");
      console.log("--------------------------------------------------------");
      session.beginDialog('Greetings');
    }
  ]);

  bot.dialog('Greetings', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Greetings Dialog Matched");
      console.log("--------------------------------------------------------");

      //Storing the bot address in config.json file
      jsonfile.readFile(botsData, function (err, botObj) {
        if (botObj == undefined || botObj == "undefined") {
          botObj = {};
          botObj.savedAddress = session.message.address;
          jsonfile.writeFile(botsData, botObj, function (err) {
            console.error(err)
          });
        } else {
          if ((botObj.savedAddress.bot.id == session.message.address.bot.id) && (botObj.savedAddress.serviceUrl == session.message.address.serviceUrl) && (botObj.savedAddress.conversation.id == session.message.address.conversation.id)) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Found the same bot Id, no need to write again");
            console.log("--------------------------------------------------------");
          } else {
            botObj = {};
            botObj.savedAddress = session.message.address;
            jsonfile.writeFile(botsData, botObj, function (err) {
              console.log("--------------------------------------------------------");
              console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | error in writing the bot info in config.json file");
              console.log("--------------------------------------------------------");
            });
          }
        }
      });

      session.send("Hi, I’m Lisa – The Employee Benefits Bot. How can I help you today?");
	  session.endDialog();
    }
  ]);
  
 dialog.matches('Capabilities', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | FinanceBot Intent Matched");
      console.log("--------------------------------------------------------");
      session.beginDialog('Capabilities');
    }
  ]);
  bot.dialog('Capabilities', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Capabilities Dialog Matched");
      console.log("--------------------------------------------------------");
	   var card = new builder.HeroCard(session)
        .title('Lisa Bot Capabilities')
        .text('I can answer questions like')
        .buttons([
            builder.CardAction.imBack(session, 'What is the policy for Travel?', 'What is the policy for Travel?'),
			builder.CardAction.imBack(session, 'What is the policy for Health?', 'What is the policy for Health?'),
			//builder.CardAction.imBack(session, 'Invoices', 'Invoices'),
        ]);
		var msg = new builder.Message(session).addAttachment(card);
	  session.send(msg);
	  session.endDialog();
    }
  ]);

  dialog.matches('FinanceBot', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | FinanceBot Intent Matched");
      console.log("--------------------------------------------------------");
      session.beginDialog('FinanceBot');
    }
  ]);
  bot.dialog('FinanceBot', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | FinanceBot Dialog Matched");
      console.log("--------------------------------------------------------");
      session.send("Lisa, The Employee Benefits bot aims for price assets based on their risk level and their expected rate of return");
	  session.endDialog();
    }
  ]);

  dialog.matches('Travel', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Travel Intent Matched");
      console.log("--------------------------------------------------------");
      session.beginDialog('Travel');
    }
  ]);
  bot.dialog('Travel', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Travel Dialog Matched");
      console.log("--------------------------------------------------------");
      session.send("Types of expenditures that are reimbursable, Inform employees of their responsibilities to control and report travel and entertainment, process for an employee to file and obtain travel expenses and reimbursement.");
      session.endDialog();
   }
  ]);

  dialog.matches('Health', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | BusinessForums Intent Matched");
      console.log("--------------------------------------------------------");
      session.beginDialog('Health');
    }
  ]);
   bot.dialog('Health', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | BusinessForums Dialog Matched");
      console.log("--------------------------------------------------------");
      session.send("Response for Health: The company provides health insurance from Meritain Health that is available for just $169/month. To know more, navigate to the link below. Response for Health: The company provides health insurance from Meritain Health that is available for just $169/month. To know more, navigate to the link - www.miraclesoft.com/health-insurance");
	   session.endDialog();
    }
  ]);

  dialog.matches('Thank you', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Thank you Dialog Matched");
      console.log("--------------------------------------------------------");
      session.send("Welcome, Nice conversation with you!");
	  session.endDialog();
    }
  ]);

  // When an irrelevant question triggers
     dialog.matches('None', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | No Help Intent Matched");
            console.log("--------------------------------------------------------");
            session.send('I’m sorry, I’m not sure what the answer to that is. Give me a second I will check if anybody else can help')
            var sfhUrl1 = {
                text: session.message.text,
                sourceBotName: process.env.botName, //get this sourceBotName from .env file
                sfhUrl: process.env.sfhUrl  //get this sourceBotName from .env file
            }
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Calling SFH service ");
            console.log("--------------------------------------------------------");
            //calling the SFH service to get the data of the bot, the irrelevant question belongs to..
            sfh.callSFH(sfhUrl1, function (response, error) {
				if(response != null){
					if(response.length >1){
                    session.send("Looks like below are the bots that can help you out, They will reach out to you directly. Let me know if I can help you with anything else ");
					var msg = new builder.Message(session)
					for(var i=0;i<response.length;i++){
						msg.addAttachment(new builder.HeroCard(session).title(response[i].destinationBot));
						if(i==(response.length-1)){
							session.send(msg);
							session.endDialog();
						}
					}
					}else{
			        session.send("Looks like " + response[0].destinationBot + "  can help you out, It will reach out to you directly. Let me know if I can help you with anything else ");
				    session.endDialog();
					}
				}else{
				    session.send("Looks like nobody knows the answer to that, would you like me to submit for a ticket?");
					session.endDialog();

				}
            });
        }
    ]);
}