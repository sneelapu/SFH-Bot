const builder = require('botbuilder');
const LUIS = require('luis-sdk');
const moment = require('moment');
const unirest = require('unirest');
const winston = require('winston');
const bodyParser = require('body-parser');
var jsonfile = require('jsonfile');
var botbuilder_azure = require("botbuilder-azure");
var fs = require('fs');
var botsData = 'data.json';
var source_bot ;
/* Questions */
var questions = [
    {field: 'user_name', question: 'Please enter the Username of your system for resetting the password'},
    {field: 'birth_place', question: 'I will need some more information in order to authenticate you. What is your place of your birth?'},
    {field: 'pet_name', question: 'What is your pet name?'},
    {field: "mother's_maiden_name", question: "What is your mother's maiden name?"}
  //  {field: 'temporary_password', question: 'Great! You passed the authentication, Your password reset is successful. Your temporary password is Miracle'+Math.random().toFixed(2)*100}
   
];
module.exports = function (server, logger) {
  // Create chat connector for communicating with the Bot Framework Service
  var connector = new builder.ChatConnector({
    appId: process.env.appId,
    appPassword: process.env.appPassword,
	openIdMetadata: "https://login.botframework.com/v1/.well-known/openidconfiguration" 

  });
  console.log(connector.botConnectorOpenIdMetadata);

 var inMemoryStorage = new builder.MemoryBotStorage();
  var bot = new builder.UniversalBot(connector).set('storage', inMemoryStorage); 

  var sfhModule = require('../../sfh_logger');
  var sfh = new sfhModule();

  var ip = require('ip').address();
  var port = server.address().port;

  //luis model url
  //var model = 'https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/b98dfe1d-8318-40c7-970d-d45121b403ac?subscription-key=dbb1c66f521d4ab18510b3f478108b24&verbose=true&timezoneOffset=0&q=';
  var model = process.env.modelUrl;
  var recognizer = new builder.LuisRecognizer(model);
  var dialog = new builder.IntentDialog({
    recognizers: [recognizer]
  });

  server.use(bodyParser.urlencoded({ extended: true }));
  server.use(bodyParser.json());

  //the endpoint of server where connector listens for messages
  server.post('/api/messages', connector.listen());

  //importing start Conversation module
  const startConversation = require('../../startConversation')

  //sending pro-active messages
  function sendProactiveMessage(add, text) {
	  
	//if((source_bot == null) || (source_bot != add.source_bot)){
				  //source_bot = add.source_bot;
	var msg = new builder.Message().address(add);
    msg.text(add.source_bot + ' Bot mentioned that you need some help')
    msg.textLocale('en-US');
	bot.send(msg);
			  //}
	bot.beginDialog(add, "*:"+text);
  }

var text;
  server.post('/receiveSFH', function (req, res) {
	  att =[];
    unirest.get(model + req.body.text)
      .headers({
        'Content-Type': 'application/json'
      })
      .end(function (response) {
		  console.log(response.body.topScoringIntent.intent);
		  console.log(response.body)
        if (response.body.topScoringIntent.intent != "None") {
          console.log("--------------------------------------------------------");
          console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Got request from the bot " + req.body.sourceBotName);
          console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | This bot can answer it");
          console.log('------------------------------------------------------------')

		  if (response.body.topScoringIntent.intent) {
            switch (response.body.topScoringIntent.intent) {
         
				case 'NetworkBot':
                    text = "NetworkBot";
                    break;
			
				case 'Broken_Policy':
                    text = "Broken_Policy";
                    break;
					
				case 'Capabilities':
                   text="Capabilities"
                    break;
					
				case 'Login_issue_Reset':
                  text="Login_issue_Reset"
				  break;
				  
				case 'Greetings':
                    text = "Greetings";
                    break;
					
            }
        }
		  
          jsonfile.readFile(botsData, function (err, botObj) {
            botObj.savedAddress.source_bot = req.body.sourceBotName;
            sendProactiveMessage(botObj.savedAddress, text);
          })
          res.send({ 'status': 'success', 'destinationBot': process.env.botName });
        }
        else {
          console.log("--------------------------------------------------------");
          console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Got request from the bot " + req.body.sourceBotName);
          console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | This bot could not able to answer for it");
          console.log('------------------------------------------------------------')
          res.send({ 'status': 'failed', 'destinationBot': process.env.botName });
        }
      });
  });

  //=========================================================
  // Bots Dialogs
  //=========================================================

  bot.dialog('/', dialog);
  
  dialog.matches('Greetings', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Greetings Intent Matched");
      console.log("--------------------------------------------------------");
      session.beginDialog('Greetings');
    }

  ]);

  bot.dialog('Greetings', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Greetings Dialog Matched");
      console.log("--------------------------------------------------------");
      //Storing the bot address in config.json file
      jsonfile.readFile(botsData, function (err, botObj) {
        if (botObj == undefined || botObj == "undefined") {
          botObj = {};
          botObj.savedAddress = session.message.address;
          jsonfile.writeFile(botsData, botObj, function (err) {
            console.error(err)
          });
        } else {
          if ((botObj.savedAddress.bot.id == session.message.address.bot.id) && (botObj.savedAddress.serviceUrl == session.message.address.serviceUrl) && (botObj.savedAddress.conversation.id == session.message.address.conversation.id)) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Found the same bot Id, no need to write again");
            console.log("--------------------------------------------------------");
          } else {
            botObj = {};
            botObj.savedAddress = session.message.address;
            jsonfile.writeFile(botsData, botObj, function (err) {
              console.log("--------------------------------------------------------");
              console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | error in writing the bot info in config.json file");
              console.log("--------------------------------------------------------");
            });
          }
        }
      });

      session.send("Hi, I’m Richard – The IT Operations Bot. How can I help you today?");
	  session.endDialog();
    }
  ]);

    dialog.matches('Capabilities', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Capabilities Intent Matched");
      console.log("--------------------------------------------------------");
	  session.beginDialog('Capabilities');
    }
  ]);
  
  bot.dialog('Capabilities', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Capabilities Dialog Matched");
      console.log("--------------------------------------------------------");
	   var card = new builder.HeroCard(session)
        .title('Richard Bot Capabilities')
        .text('I can answer questions like ')
        .buttons([
            builder.CardAction.imBack(session, 'What is the policy for Broken items?', 'What is the policy for Broken items?'),
			builder.CardAction.imBack(session, 'Want to reset my system password?', 'Want to reset my system password?')
        ]);
		var msg = new builder.Message(session).addAttachment(card);
	  session.send(msg);
	  session.endDialog();
    }

  ]);

  dialog.matches('NetworkBot', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | NetworkBot Intent Matched");
      console.log("--------------------------------------------------------");
     // session.send("Richard, The IT Operations bot is responsible for overseeing employee-benefits design, employee recruitment, training and development, performance appraisal, and rewarding ");
	  session.beginDialog('NetworkBot');
    }
  ]);
  bot.dialog('NetworkBot', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | NetworkBot Dialog Matched");
      console.log("--------------------------------------------------------");
      session.send("Richard, The IT Operations bot is responsible for overseeing employee-benefits design, employee recruitment, training and development, performance appraisal, and rewarding ");
    session.endDialog();
	}
  ]);


   dialog.matches('Broken_Policy', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Routers Intent Matched");
      console.log("--------------------------------------------------------");
	  session.beginDialog('Broken_Policy');
    }
  ]); 
  
  bot.dialog('Broken_Policy', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Routers Dialog Matched");
      console.log("--------------------------------------------------------");
      session.send("You will be held financially liable and will be billed accordingly!!!");
	  session.endDialog();
    }

  ]); 
  
  dialog.matches('Login_issue_Reset', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Login_issue_Reset Intent Matched");
      console.log("--------------------------------------------------------");
      //session.send("This is a test login intent");
	  session.beginDialog('Login_issue_Reset');
    }
  ]);

  bot.dialog('Login_issue_Reset', [
    function (session, args) {
		 session.dialogData.index = args ? args.index : 0;
        session.dialogData.form = args ? args.form : {};
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Login_issue_Reset Dialog Matched");
      console.log("--------------------------------------------------------");
     // session.send("This is a password reset intent1");
	  builder.Prompts.text(session, questions[session.dialogData.index].question);
    },
	 function (session, results) {
		   // Save users reply
        var field = questions[session.dialogData.index++].field;
        session.dialogData.form[field] = results.response;

        // Check for end of form
        if (session.dialogData.index >= questions.length) {
		session.send('Great! You passed the authentication, Your password reset is successful. Your temporary password is Miracle'+Math.random().toFixed(2)*100)
            session.privateConversationData.portForm = session.dialogData.form;
            session.endDialog();
        } else {
            session.replaceDialog('Login_issue_Reset', session.dialogData);
        }
    }

  ]);

  dialog.matches('Thank you', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Thank you Intent Matched");
      console.log("--------------------------------------------------------");
      session.send("Thanks, have a great day!");
    }

  ]);

    dialog.matches('None', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | No Help Intent Matched");
      console.log("--------------------------------------------------------");
	  session.beginDialog('None');
    }
  ]);
 // When an irrelevant question triggers
     bot.dialog('None', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | No Help Dialog Matched");
            console.log("--------------------------------------------------------");
            session.send('I’m sorry, I’m not sure what the answer to that is. Give me a second I will check if anybody else can help')
            var sfhUrl1 = {
                text: session.message.text,
                sourceBotName: process.env.botName, //get this sourceBotName from .env file
                sfhUrl: process.env.sfhUrl  //get this sourceBotName from .env file
            }
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Calling SFH service ");
            console.log("--------------------------------------------------------");
            //calling the SFH service to get the data of the bot, the irrelevant question belongs to..
            sfh.callSFH(sfhUrl1, function (response, error) {
				if(response != null){
					if(response.length >1){
                    session.send("Looks like below are the bots that can help you out, They will reach out to you directly. Let me know if I can help you with anything else ");
					var msg = new builder.Message(session)
					for(var i=0;i<response.length;i++){
						msg.addAttachment(new builder.HeroCard(session).title(response[i].destinationBot));
						if(i==(response.length-1)){
							session.send(msg);
							session.endDialog();
						}
					}
					}else{
			        session.send("Looks like " + response[0].destinationBot + "can help you out, It will reach out to you directly. Let me know if I can help you with anything else ");
					session.endDialog();
				    }
				}else{
				    session.send("Looks like nobody knows the answer to that, would you like me to submit for a ticket?");
					session.endDialog();

				}
            });
        }
    ]);
	} 