const logger = require('./app/_log/logger_def.js');
//other deps
const express = require('express');
const bodyParser = require('body-parser');
//Importing Mongoose library
const mongoose = require('mongoose');
require('dotenv').config();
const app = express();
const router = express.Router();
var port = process.env.PORT || 8000;

console.log("Application Environment : " + app.settings.env);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
var config = require('./_config');
//Enabling CORS
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

//Connecting to the MongoDB database 'document_db' running on 27017
//enable the mongoose database uri for both testing and development
mongoose.connect(config.mongoURI[app.settings.env]);

mongoose.connection.on('error', (err) => {
  logger.error(err.message);
});

mongoose.connection.once('open', () => {
  logger.info("Connected to the DB at : " + config.mongoURI[app.settings.env]);
});

//import routes
require('./app/routes/bot_routes')(app, router, logger);

app.listen(port);
console.log("Server started at: " + port);
module.exports = app;