const logger = require('../_log/logger_def.js');
const mongoose = require('mongoose');
const Bot = require('../models/botModel');
var async = require('async');
var unirest = require('unirest');

//Create or update a bot
exports.createOrUpdate = function (req, res) {
  Bot.findOne({
    "botName": req.body.botName
  })
    .then((singleBot) => {
      if (singleBot) {
        logger.info('Error creating duplicate bot: ' + singleBot._id);
        res.status(200).send('Bot name already exists, Please try with different name');
      } else {
        var newBot = new Bot(req.body)
        newBot.save()
          .then((newBotObj) => {
            logger.info("created bot with _id: " + newBotObj._id);
            res.status(200).send(newBotObj);
          })
      }
    })
};

module.exports.callSFH = function (req, res) {
  Bot.find({})
    .then((allbots) => {
		var json = [];
      var count = 0;
      async.each(allbots, function (botObj, callback1) {
        //checking the bots which is able to respond to the user
        if (botObj.sfhUrl == req.body.sfhUrl) {
          if (count == (allbots.length - 1)) {
            logger.info("We have not found any other bot to respond you back");
            console.log("We have not found any other bot to respond you back");
            res.status(200).send({ 'status': 'failed' });
          }
		  else{
			  if((count+json.length+1) == allbots.length){
				  console.log(json);
                res.status(200).send(json);
				}
		  }
        } else {
          unirest.post(botObj.sfhUrl)
            .headers({
              'Content-Type': 'application/json'
            })
            .send(req.body)
            .end(function (response) {
              if (response.body.status == "success") {
                logger.info(response.body.destinationBot + " can respond you back");
                console.log(response.body.destinationBot + " can respond you back");
				json.push(response.body);
				if((count+json.length+1) == allbots.length){
                res.status(200).send(json);
				}
              }
              else {
                count++;
                if (count == (allbots.length - 1)) {
                  logger.info("We have not found any other bot to respond you back");
                  console.log("We have not found any other bot to respond you back");
                  res.status(200).send({ 'status': 'failed' });
                }
				else{
					if((count+json.length+1) == allbots.length){
                res.status(200).send(json);
				}
				}
              }
            });
        }
      });
    })
    .catch((err) => {
      logger.info("Something went wrong");
      console.log("Something went wrong");
      res.status(500).send("error");
    })

}