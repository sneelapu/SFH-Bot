const botcontroller = require("../controllers/botController.js");

module.exports = function(app, router, logger){
   app.route('/registerBot')
  .post(botcontroller.createOrUpdate)
  
   app.route('/SFH')
  .post(botcontroller.callSFH)
}
