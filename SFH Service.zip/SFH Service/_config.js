var config = {};

config.mongoURI = {
  development: 'mongodb://pavani:pavani439@ds151180.mlab.com:51180/document_db'
};

module.exports = config;
