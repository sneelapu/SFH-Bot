const builder = require('botbuilder');
const LUIS = require('luis-sdk');
const moment = require('moment');
const unirest = require('unirest');
const winston = require('winston');
const startConversation = require('../../startConversation');
const bodyParser = require('body-parser');
var jsonfile = require('jsonfile');
var fs = require('fs');
var botsData = 'data.json';



module.exports = function (server, logger) {
    // Create chat connector for communicating with the Bot Framework Service
    var connector = new builder.ChatConnector({
        appId: process.env.appId,
        appPassword: process.env.appPassword
    });
	
	var inMemoryStorage = new builder.MemoryBotStorage();
  var bot = new builder.UniversalBot(connector).set('storage', inMemoryStorage); 

    var sfhModule = require('../../sfh_logger');
    var sfh = new sfhModule();

    var ip = require('ip').address();
    var port = server.address().port;

    //luis model url
    //var model = 'https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/074962cb-113f-448d-a4d9-33befdf84708?subscription-key=dbb1c66f521d4ab18510b3f478108b24&verbose=true&timezoneOffset=0&q=';

    var model = process.env.modelUrl;
    var recognizer = new builder.LuisRecognizer(model);
    var dialog = new builder.IntentDialog({
        recognizers: [recognizer]
    });

    server.use(bodyParser.urlencoded({ extended: true }));
    server.use(bodyParser.json());

    //the endpoint of server where connector listens for messages
    server.post('/api/messages', connector.listen());

    //importing start Conversation module
    const startConversation = require('../../startConversation')

    function sendProactiveMessage(add, text) {
	  
	//if((source_bot == null) || (source_bot != add.source_bot)){
				  //source_bot = add.source_bot;
	var msg = new builder.Message().address(add);
    msg.text(add.source_bot + ' Bot mentioned that you need some help')
    msg.textLocale('en-US');
	bot.send(msg);
			  //}
	bot.beginDialog(add, "*:"+text);
  }

var text;
    server.post('/receiveSFH', function (req, res) {
        unirest.get(model + req.body.text)
            .headers({
                'Content-Type': 'application/json'
            })
            .end(function (response) {
                if (response.body.topScoringIntent.intent != "None") {
                    console.log("--------------------------------------------------------");
                    console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Got request from the bot " + req.body.sourceBotName);
                    console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | This bot can answer it");
                    console.log('------------------------------------------------------------')
					
					   if (response.body.topScoringIntent.intent) {
            switch (response.body.topScoringIntent.intent) {
         
				case 'HrBot':
                    text = "HrBot";
                    break;
				case 'Docs':
                    text = "Docs";
                    break;
				case 'office_timings':
                    text = "office_timings";
                    break;
				case 'Capabilities':
                    text = "Capabilities";
                    break;
				case 'Leave':
                    text = "Leave";
                    break;
            }
        }
					

                    jsonfile.readFile(botsData, function (err, botObj) {
                        botObj.savedAddress.source_bot = req.body.sourceBotName;
                        sendProactiveMessage(botObj.savedAddress,text);
                    })
					
                    res.send({ 'status': 'success', 'destinationBot': process.env.botName });
                }
                else {
                    console.log("--------------------------------------------------------");
                    console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Got request from the bot " + req.body.sourceBotName);
                    console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | This bot could not able to answer for it");
                    console.log('------------------------------------------------------------')
                    res.send({ 'status': 'failed', 'destinationBot': process.env.botName });
                }
            });
    });

    //=========================================================
    // Bots Dialogs
    //=========================================================

    bot.dialog('/', dialog);
	
	 dialog.matches('Greetings', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Greetings Intent Matched");
            console.log("--------------------------------------------------------");
			session.beginDialog('Greetings')
		}
		])
		
    bot.dialog('Greetings', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Greetings Dialog Matched");
            console.log("--------------------------------------------------------");

            //Storing the bot address in config.json file
            jsonfile.readFile(botsData, function (err, botObj) {
                if (botObj == undefined || botObj == "undefined") {
                    botObj = {};
                    botObj.savedAddress = session.message.address;
                    jsonfile.writeFile(botsData, botObj, function (err) {
                        console.error(err)
                    });
                } else {
                    if ((botObj.savedAddress.bot.id == session.message.address.bot.id) && (botObj.savedAddress.serviceUrl == session.message.address.serviceUrl) && (botObj.savedAddress.conversation.id == session.message.address.conversation.id)) {
                        console.log("--------------------------------------------------------");
                        console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Found the same bot Id, no need to write again");
                        console.log("--------------------------------------------------------");
                    } else {
                        botObj = {};
                        botObj.savedAddress = session.message.address;
                        jsonfile.writeFile(botsData, botObj, function (err) {
                            console.log("--------------------------------------------------------");
                            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | error in writing the bot info in config.json file");
                            console.log("--------------------------------------------------------");
                        });
                    }
                }
            });

            session.send("Hi, I’m Edward – The HR Operations Bot. How can I help you today?");
			session.endDialog();
        }
    ]);
	
dialog.matches('Capabilities', [
        function (session, args) {
           console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Capabilities Intent Matched");
      console.log("--------------------------------------------------------");
			 session.beginDialog('Capabilities');
        }
    ]);
    
	bot.dialog('Capabilities', [
    function (session, args) {
      console.log("--------------------------------------------------------");
      console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Capabilities Dialog	Matched");
      console.log("--------------------------------------------------------");
	   var card = new builder.HeroCard(session)
        .title('Edward Bot Capabilities')
        .text('I can answer questions like ')
        .buttons([
			builder.CardAction.imBack(session, 'Want to apply for leave', 'Want to apply for leave'),
			builder.CardAction.imBack(session, 'Can I get the on-boarding docs for further assistance?', 'Can I get the on-boarding docs for further assistance?'),
			builder.CardAction.imBack(session, 'What would be the shift timings for ITG resources?', 'What would be the shift timings for ITG resources?')
			
        ]);
	  var msg = new builder.Message(session).addAttachment(card);
	  session.send(msg);
	  session.endDialog();
    }
  ]);
 
	
	  dialog.matches('HrBot', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | HrBot Intent Matched");
            console.log("--------------------------------------------------------");
			 session.beginDialog('HrBot');
        }
    ]);
	bot.dialog('HrBot', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | HrBot Dialog Matched");
            console.log("--------------------------------------------------------");
            session.send("Edward, The HR Operations bot is responsible for overseeing employee-benefits design, employee recruitment, training and development, performance appraisal, and rewarding (e.g., managing pay and benefit systems)");
       session.endDialog();
	   }

    ]);
	
	dialog.matches('Docs', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Docs Intent Matched");
            console.log("--------------------------------------------------------");
 session.beginDialog('Docs');       
	   }
	   ]);
	
    bot.dialog('Docs', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Docs Dialog Matched");
            console.log("--------------------------------------------------------");
            session.send("Here are the documents that you will need to fill out and return to hrbot.miraclesoft@gmail.com. Link: http://www.miraclesoft.com/onboarding Please send the filled documents to hrbot.miraclesoft@gmail.com ASAP. If you have any questions, please reach out to us and we will guide you through the process.");
       session.endDialog();
	   }

    ]);
dialog.matches('office_timings', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | office_timings Intent Matched");
            console.log("--------------------------------------------------------");
            session.beginDialog('office_timings');
        }

    ]);
    bot.dialog('office_timings', [
        function (session, args) {
			console.log(session);
			console.log(args);
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | office_timings Dialog Matched");
            console.log("--------------------------------------------------------");
            session.send("Works from 9 AM to 5 PM");
			session.endDialog();
        }

    ]);

   dialog.matches('Leave', [
        function (session, results,next) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Leave Intent Matched");
            console.log("--------------------------------------------------------");
           session.beginDialog('Leave');
        }
    ]);
	

	/*
	dialog.matches('Leave', 
	[
	function (session,results,next) {
		if(results.entities.length == 0){
			next();
		}
		else{
		if(results.entities[0].type == "builtin.datetimeV2.daterange"){
			 session.dialogData.leaveStartDate = results.entities[0].resolution.values[0].start;
			 session.dialogData.leaveEndDate = results.entities[0].resolution.values[0].end;
		//builder.Prompts.text(session, "So, you want to apply for leave from "+session.dialogData.leaveStartDate+" to "+session.dialogData.leaveEndDate+". Can you please give me a reason for this leave?");
		builder.Prompts.text(session, "So, you want to apply for leave from "+results.entities[0].entity+". Can you please give me a reason for this leave?");
		}
		}
    },
	function (session,results,next) {
		if(!session.dialogData.leaveStartDate){
		builder.Prompts.time(session, "Please provide the leave start date (e.g.: June 6th)");
}
else{
	next();
}
    },
	function (session,results,next) {
		if(!session.dialogData.leaveEndDate){
			console.log(results.response);
		//session.dialogData.leaveStartDate = builder.EntityRecognizer.resolveTime([results.response]);
	  session.dialogData.leaveStartDate = results.response.entity;
		builder.Prompts.time(session, "Please provide the leave end date (e.g.: June 7th)");
		}
		else{
	next();
}
    },
	function (session,results,next) {
		if(!session.dialogData.leaveEndDate){
			//session.dialogData.leaveEndDate = builder.EntityRecognizer.resolveTime([results.response]);
			session.dialogData.leaveEndDate = results.response.entity;
		builder.Prompts.text(session, "So, you want to apply for leave from "+session.dialogData.leaveStartDate+" to "+session.dialogData.leaveEndDate+". Can you please give me a reason for this leave?");
		}
		else{
	next();
}
    },
	function (session,results,next) {
		session.dialogData.reason = session.message.text;
		builder.Prompts.text(session, "Your leave request from "+session.dialogData.leaveStartDate+" to "+session.dialogData.leaveEndDate+" with reason '"+session.dialogData.reason+"' has been submitted successfully.");
    // session.send(`Your leave request from ${session.dialogData.leaveStartDate} to ${session.dialogData.leaveEndDate} with reason ${session.dialogData.reason} has been submitted successfully.`)
	 session.endDialog();
	}
]);*/

	bot.dialog('Leave', 
	[
	function (session,results,next) {
		if(!session.dialogData.leaveStartDate){
		builder.Prompts.time(session, "Please provide the leave start date (e.g.: June 6th)");
}
else{
	next();
}
    },
	function (session,results,next) {
		if(!session.dialogData.leaveEndDate){
			console.log(results.response);
		//session.dialogData.leaveStartDate = builder.EntityRecognizer.resolveTime([results.response]);
	  session.dialogData.leaveStartDate = results.response.entity;
		builder.Prompts.time(session, "Please provide the leave end date (e.g.: June 7th)");
		}
		else{
	next();
}
    },
	function (session,results,next) {
		if(!session.dialogData.leaveEndDate){
			//session.dialogData.leaveEndDate = builder.EntityRecognizer.resolveTime([results.response]);
			session.dialogData.leaveEndDate = results.response.entity;
		builder.Prompts.text(session, "So, you want to apply for leave from "+session.dialogData.leaveStartDate+" to "+session.dialogData.leaveEndDate+". Can you please give me a reason for this leave?");
		}
		else{
	next();
}
    },
	function (session,results,next) {
		session.dialogData.reason = session.message.text;
		builder.Prompts.text(session, "Your leave request from "+session.dialogData.leaveStartDate+" to "+session.dialogData.leaveEndDate+" with reason '"+session.dialogData.reason+"' has been submitted successfully.");
    // session.send(`Your leave request from ${session.dialogData.leaveStartDate} to ${session.dialogData.leaveEndDate} with reason ${session.dialogData.reason} has been submitted successfully.`)
	 session.endDialog();
	}
]);

    dialog.matches('Thank you', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Thank you Intent Matched");
            console.log("----------------------------s----------------------------");
            session.send("Thank you!");
			
        }
    ]);

	
    // When an irrelevant question triggers
     dialog.matches('None', [
        function (session, args) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | No Help Intent Matched");
            console.log("--------------------------------------------------------");
            session.send('I’m sorry, I’m not sure what the answer to that is. Give me a second I will check if anybody else can help')
            var sfhUrl1 = {
                text: session.message.text,
                sourceBotName: process.env.botName, //get this sourceBotName from .env file
                sfhUrl: process.env.sfhUrl  //get this sourceBotName from .env file
            }
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | Calling SFH service ");
            console.log("--------------------------------------------------------");
            //calling the SFH service to get the data of the bot, the irrelevant question belongs to..
            sfh.callSFH(sfhUrl1, function (response, error) {
				if(response != null){
					if(response.length >1){
                    session.send("Looks like below are the bots that can help you out, They will reach out to you directly. Let me know if I can help you with anything else ");
					var msg = new builder.Message(session)
					for(var i=0;i<response.length;i++){
						msg.addAttachment(new builder.HeroCard(session).title(response[i].destinationBot));
						if(i==(response.length-1)){
							session.send(msg);
							session.endDialog();
						}
					}
					}else{
			        session.send("Looks like " + response[0].destinationBot + "  can help you out, It will reach out to you directly. Let me know if I can help you with anything else ");
				    session.endDialog();
					}
				}else{
				    session.send("Looks like nobody knows the answer to that, would you like me to submit for a ticket?");
session.endDialog();
				}
            });
        }
    ]);
} 