//this file is to post the data to the partcular bot
var unirest = require('unirest');
require('dotenv').config();
var moment = require('moment')
var bot_token = null, limit = 0, lastUpdatedTime = 0;
var authData = {
  "grant_type": "client_credentials",
  "scope": "https://api.botframework.com/.default",
  "client_id": process.env.appId,
  "client_secret": process.env.appPassword
}

module.exports = function (bot_data, text, callback) {
  var postMessage_Data = {
    "type": "message",
    "text": text,
    "from": {
      "id": bot_data.user.id,
      "name": bot_data.user.name
    },
    "conversation": {
      "id": bot_data.conversation.id
    },
    "recipient": {
      "id": bot_data.bot.id,
      "name": bot_data.bot.name
    }
  }

  function postMessage(token, callback) {
	  console.log(bot_data.serviceUrl);
    unirest.post(bot_data.serviceUrl+'/v3/conversations/'+bot_data.conversation.id+'/activities')
      .headers({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token,
        //'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IlRpb0d5d3dsaHZkRmJYWjgxM1dwUGF5OUFsVSJ9.eyJhdWQiOiJkYjU0YmRiZC1iMDhlLTQxNzItODhmZS05ODM5YThiNzM3MDciLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vZDZkNDk0MjAtZjM5Yi00ZGY3LWExZGMtZDU5YTkzNTg3MWRiL3YyLjAiLCJpYXQiOjE1MzEzMzM2NzcsIm5iZiI6MTUzMTMzMzY3NywiZXhwIjoxNTMxMzM3NTc3LCJhaW8iOiJZMmRnWUhnYUtIMGsxbWRGN2Fyd1h3MDd2YnB2QXdBPSIsImF6cCI6ImRiNTRiZGJkLWIwOGUtNDE3Mi04OGZlLTk4MzlhOGI3MzcwNyIsImF6cGFjciI6IjEiLCJ0aWQiOiJkNmQ0OTQyMC1mMzliLTRkZjctYTFkYy1kNTlhOTM1ODcxZGIiLCJ1dGkiOiJjV2p5bFJxdnhVYVBrdmZSRFNnTkFBIiwidmVyIjoiMi4wIn0.We7LEMurwbt5A93yEK1VFql2lNaDt5hxSr_mE9bQKEpyH26IqK2PxToiwRr_tn4aKnlSpzrdJMd_p2NLSvWMfNQf-oyhAbqY5AQdjnFjNYz9O_FGmQVsLUx_MynDpQllgZNLSY_ZDKeC6o-TtUYJPxVcNvoI08QvUGGrPCdfCtygD3afgg5cyecw99BAaXP9_8mknckvkyi5lsxa7lnQXLkFQydU9hqd9Z33YS1B3S7TIK4mtycpDWnGO9Z70uz1rfyP6dQegKm7lY_ZbwbVvvFm02OmIKzW6yxwIxWpghijYW8EFw_x1pQeH8X3fROUDKzIJsL2SiwqJDJ08rmbYA'
      })
      .send(postMessage_Data)
      .end(function (response) {
        if (response)
          callback("success", null);
        else
          callback(null, "error")
      });
  }


  var getBotToken = function () {
    return new Promise(function (resolve, reject) {
      unirest.post('https://login.microsoftonline.com/botframework.com/oauth2/v2.0/token')
        .headers({
          'Content-Type': 'application/x-www-form-urlencoded',
          'host': 'login.microsoftonline.com'
        })
        .send(authData)
        .end(function (response) {
          if (response.body != undefined) {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | getting the Bot Token ");
            console.log("--------------------------------------------------------");
			console.log(response.body);
            resolve(response.body);
          }
          else {
            console.log("--------------------------------------------------------");
            console.log(moment().format('MMMM Do YYYY, hh:mm:ss a') + " | something went in getting the Bot Token ");
            console.log("--------------------------------------------------------");
          }
        });
    })
  }

  if ((bot_token == null) || (limit == null) || (moment.duration(moment(new Date(), "DD/MM/YYYY HH:mm:ss").diff(new Date(lastUpdatedTime))).asSeconds() > limit)) {
    getBotToken().then(function (data) {
      bot_token = data.access_token;
      limit = data.expires_in;
      lastUpdatedTime = new Date();
      postMessage(data.access_token, function (postMessageResult, error) {
        if (postMessageResult != null)
          callback("success", null);
        else
          callback(null, "error")
      });
    })
  } else {
    console.log(moment.duration(moment(new Date(), "DD/MM/YYYY HH:mm:ss").diff(new Date(lastUpdatedTime))).asSeconds());
    console.log(limit);
    postMessage(bot_token, function (postMessageResult, error) {
      if (postMessageResult != null)
        callback("success", null);
      else
        callback(null, "error")
    });
  }
}


