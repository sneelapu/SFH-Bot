const unirest = require('unirest');
var isArray = require('isarray');
require('dotenv').config();
var sfhModule = function () { };

sfhModule.prototype.callSFH = function (botObj, callback) {
  if (botObj) {
    reportMessage1(botObj, function (response, error) {
      callback(response, error);
    });
  }
}

module.exports = sfhModule;
function reportMessage1(botData, callback) {
  unirest.post('http://localhost:8000/SFH/')
    .headers({
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    })
    .send(botData)
    .end(function (response) {
		if(response.body != undefined){
			if(Array.isArray(response.body)){
				 callback(response.body, null)
			}
			else{
				callback(null, response.body)
			}
		}
    });
}